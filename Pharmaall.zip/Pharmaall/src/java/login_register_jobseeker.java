/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import Captcha.CaptchasDotNet;
import com.mysql.jdbc.Util;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import javax.servlet.http.HttpSession;


public class login_register_jobseeker extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String firstname=request.getParameter("firstname");
        String lastname=request.getParameter("lastname");
        String email=request.getParameter("email");
        String password=request.getParameter("pwd");
        String address=request.getParameter("address");
        String pincode=request.getParameter("pincode");
        String phoneno=request.getParameter("phoneno");

        CaptchasDotNet Captcha = new Captcha.CaptchasDotNet
        (
  request.getSession(true),     // Ensure session
  "demo",                       // client
  "secret"                      // secret
  );
           String c = request.getParameter("captcha");

// Check captcha
switch (Captcha.check(c)) {
  case 's':
   // body = "Session seems to be timed out or broken. ";
   // body += "Please try again or report error to administrator.";
     out.println("<script type='text/javascript'> alert('Session seems to be timed out or broken, Please try again or report error to administrator.'); window.location.href='jobseeker.jsp'; </script>");
    break;
  case 'm':
    //body = "Every CAPTCHA can only be used once. ";
   // body += "The current CAPTCHA has already been used. ";
   // body += "Please use back button and reload";
     out.println("<script type='text/javascript'> alert('The current CAPTCHA has already been used.'); window.location.href='jobseeker.jsp'; </script>");
    break;
  case 'w':
   // body = "You entered the wrong password. ";
   // body += "Please use back button and try again. ";
     out.println("<script type='text/javascript'> alert('You entered the wrong captcha..!'); window.location.href='jobseeker.jsp'; </script>");
    break;

}


        try {

            ConnectionClass cn=new ConnectionClass();
            int id=0,id1=0;

            java.util.Date utilDate = new java.util.Date();

            java.sql.Date date = new java.sql.Date(utilDate.getTime());
            Time time=new Time(utilDate.getTime());

            String l="select Id from tbl_jobseeker_login";
            ResultSet rs=cn.getData(l);
            while(rs.next()){ id=rs.getInt("Id"); }

            String v="select Id from tbl_js_login_check";
            ResultSet m=cn.getData(v);
            while(m.next()){  id1=m.getInt("Id");  }




           String query="insert into tbl_jobseeker_login values('"+(id+1)+"','"+firstname+"','"+lastname+"','"+email+"','"+password+"','"+phoneno+"','"+address+"','"+pincode+"','"+date+"')";
           String j="insert into tbl_js_login_check values('"+(id1+1)+"','"+email+"','"+password+"','"+date+"','"+time+"')";
            int k=cn.operatedata(query);
           int u=cn.operatedata(j);

            if(k==1 && u==1)
            {
                String p="select Id from tbl_jobseeker_login where Email='"+email+"'";
            ResultSet rs2=cn.getData(p);
                HttpSession session=request.getSession();
                   // session.setAttribute("name",firstname);
                 while(rs2.next()){   session.setAttribute("L_id",rs.getInt("Id")); 
                        session.setAttribute("username",email); }
                        //session.setAttribute("password",password);
                response.sendRedirect("jobseeker_profile.jsp");
                

            }

        }
        catch(Exception e)
        {
            out.println(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
