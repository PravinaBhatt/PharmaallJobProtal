/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.sun.org.apache.bcel.internal.generic.LADD;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class reg_js_profile extends HttpServlet {
   
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

            //for both(fresher & experienced)
        String fname=request.getParameter("firstname");
        String lname=request.getParameter("lastname");
        String dob=request.getParameter("dob");
        String country=request.getParameter("country");
        String city=request.getParameter("city");
        String gender=request.getParameter("gender");

        String type=request.getParameter("experience");
        String total_ex=request.getParameter("ex_months");
        String func_area=request.getParameter("functional_area");

        String qualification=request.getParameter("qualification_level");
        String specialization=request.getParameter("specialization");
        String institute=request.getParameter("institutename");
        String course_type=request.getParameter("coursetype");

        //for experienced
        String current_job_title=request.getParameter("jobtitle");
        String company_name=request.getParameter("companyname");
        String industry=request.getParameter("industry");
        String duration=request.getParameter("duration");


        String skill_title1=request.getParameter("keyskill_word1");
        String skill_years1=request.getParameter("skill_years1");
        
        String skill1=skill_title1+","+skill_years1;

        String skill_title2=request.getParameter("keyskill_word2");
        String skill_years2=request.getParameter("skill_years2");
       
        String skill2=skill_title2+","+skill_years2;

        String skill_title3=request.getParameter("keyskill_word3");
        String skill_years3=request.getParameter("skill_years3");
       
        String skill3=skill_title3+","+skill_years3;

        String skill_title4=request.getParameter("keyskill_word4");
        String skill_years4=request.getParameter("skill_years4");
       
        String skill4=skill_title4+","+skill_years4;

        String skill_title5=request.getParameter("keyskill_word5");
        String skill_years5=request.getParameter("skill_years5");
      
        String skill5=skill_title5+","+skill_years5;

        String resume=request.getParameter("resume");
        
        try {

            ConnectionClass cn=new  ConnectionClass();

                int id=0;
                String query1="select Id from tbl_jobseeker_profile";
                ResultSet rs=cn.getData(query1);
                while(rs.next()){ id=rs.getInt("Id"); }
                HttpSession session=request.getSession();
                if(type.equals("fresher"))
                {
                    String query2="insert into tbl_jobseeker_profile(L_Id,Id,Fname,Lname,Birthdate,Country,City,Gender,Type,Total_experience,Functional_area,Qualification,Specialization,Institute,Course_type,Resume) values('"+session.getAttribute("L_id")+"','"+(id+1)+"','"+fname+"','"+lname+"','"+dob+"','"+country+"','"+city+"','"+gender+"','"+type+"','"+total_ex+"','"+func_area+"','"+qualification+"','"+specialization+"','"+institute+"','"+course_type+"','"+resume+"')";
                    int l=cn.operatedata(query2);
                    if(l==1)
                    {
                        response.sendRedirect("jobseeker_login_home.jsp");
                    }
                            
                            
                            
                    else
                    {
                        out.println("<script type='text/javascript'>alert('Invalid data! please Reinsert!'); window.location.href='jobseeker_profile.jsp'; </script>");
                    }
                  

                }
                else
                {
                  String q1="insert into tbl_jobseeker_profile  values('"+session.getAttribute("L_id")+"','"+(id+1)+"','"+fname+"','"+lname+"','"+dob+"','"+country+"','"+city+"','"+gender+"','"+type+"','"+total_ex+"','"+func_area+"','"+qualification+"','"+specialization+"','"+institute+"','"+course_type+"','"+current_job_title+"','"+company_name+"','"+industry+"','"+duration+"','"+skill1+"','"+skill2+"','"+skill3+"','"+skill4+"','"+skill5+"','" +resume+"')";
                    int l=cn.operatedata(q1);
                    if(l==1)
                    {
                        response.sendRedirect("jobseeker_login_home.jsp");
                    }
                            
                            
                            
                    else
                    {
                        out.println("<script type='text/javascript'>alert('Invalid data! please Reinsert!'); window.location.href='jobseeker_profile.jsp'; </script>");
                    }
                  

                }



        } catch(Exception e)
        {
            out.println(e);
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
