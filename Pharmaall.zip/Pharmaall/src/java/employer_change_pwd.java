/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Radhika
 */
public class employer_change_pwd extends HttpServlet {
   
  
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String old_pwd=request.getParameter("old_pwd");
        String new_pwd=request.getParameter("new_pwd");
        String c_pwd=request.getParameter("cnfirm_pwd");
        HttpSession session=request.getSession();

        try {

            ConnectionClass cn=new ConnectionClass();
            String query="select Password from tbl_employer_profile where Id='"+session.getAttribute("employer_id")+"'";
            ResultSet rs=cn.getData(query);
            String pwd="";
          while(rs.next()){ pwd=rs.getString("Password"); }

        if(!old_pwd.equals(pwd))
          {
              out.println("<script type='text/javascript'>alert('Forgot your old pwd?'); window.location.href='employer_account_settings.jsp';</script>");

          }
 else if(!(new_pwd.equals(c_pwd)))
        {
     out.println("<script type='text/javascript'>alert('Confirm password doesnt match!'); window.location.href='employer_account_settings.jsp';</script>");

 }

            else
          {
              String q2="update tbl_employer_profile set Password='"+(new_pwd)+"' where Id='"+(session.getAttribute("employer_id"))+"'";

           int l=cn.operatedata(q2);
           if(l==1)
            {
                response.sendRedirect("employer_home.jsp?done=Password changed successfully!");

           }
            else
            {
             out.println("<script type='text/javascript'>alert('Error updating!'); return false; </script>");

            }
            }



        }
        catch(Exception e)
        {
            out.println(e);
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
