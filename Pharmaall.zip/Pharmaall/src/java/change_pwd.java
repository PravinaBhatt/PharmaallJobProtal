/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Radhika
 */
public class change_pwd extends HttpServlet {
   
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String old_pwd=request.getParameter("old_pwd");
        String new_pwd=request.getParameter("new_pwd");
        HttpSession session=request.getSession();

        try
        {
           ConnectionClass cn=new ConnectionClass();
          String q1="select Password from tbl_jobseeker_login where Id='"+(session.getAttribute("L_id"))+"'";
          ResultSet rs=cn.getData(q1);
          String pwd="";
          while(rs.next()){pwd=rs.getString("Password"); }

          if(!old_pwd.equals(pwd))
          {
              out.println("<script type='text/javascript'>alert('Forgot your old pwd?'); window.location.href='jobseeker_accountsettings.jsp';</script>");
              
          }
            else
          {
              String q2="update tbl_jobseeker_login set Password='"+(new_pwd)+"' where Id='"+(session.getAttribute("L_id"))+"'";

           int l=cn.operatedata(q2);
           if(l==1)
            {
                out.println("<center><h2>Password changed successfully!</h2></center>");
               response.setHeader("Refresh","1; URL=http://localhost:8080/Pharmaall/jobseeker_accountsettings.jsp");

           }
            else
            {
             out.println("<script type='text/javascript'>alert('Error updating!'); return false; </script>");

            }
            }
            
           
            

   } 
        catch(Exception e)
        {
            out.println(e);
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
