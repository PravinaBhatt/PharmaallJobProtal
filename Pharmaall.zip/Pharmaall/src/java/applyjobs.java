/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author DVP
 */
public class applyjobs extends HttpServlet {
   
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session=request.getSession();
        String jobseeker_id=session.getAttribute("id").toString();
        String employer_id=request.getParameter("employer_id");
        String job_title=request.getParameter("jobtitle");
        String job_id=request.getParameter("job_id");
        try {
                   ConnectionClass cn=new ConnectionClass();
                  

                   String n="select * from tbl_applied_jobs where Job_id='"+Integer.parseInt(job_id)+"' and Jobseeker_id='"+Integer.parseInt(jobseeker_id)+"'";
                   ResultSet m=cn.getData(n);
                   if(m.next())
                   {
                            out.println("<center><h2>You had already applied for this job!</h2></center>");
                   }
                else
                   {

                   String l="insert into tbl_applied_jobs values('"+Integer.parseInt(job_id)+"','"+Integer.parseInt(jobseeker_id)+"','"+Integer.parseInt(employer_id)+"','"+job_title+"')";
                    int j=cn.operatedata(l);
                    if(j==1)
                    {
                        out.println("<center><h2>Applied for the job..redirecting</h2></center>");
                    }
                    else
                    {
                                     out.println("<script type='text/javascript'>alert('Error applying for the job!');</script>");
                        }
            }
        } 
        catch(Exception e)
        {
                out.println(e);
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
