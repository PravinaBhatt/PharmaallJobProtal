/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.*;
public class ConnectionClass
{  Connection cn;
    Statement st;
    ResultSet rs;


  
  public ConnectionClass() throws Exception
    {
         Class.forName("com.mysql.jdbc.Driver");
        cn = DriverManager.getConnection("jdbc:mysql://localhost/db_pharmaall","root","root");
        st = cn.createStatement();


    }
   public ResultSet getData(String strQuery)
    {
        try
        {
            rs = st.executeQuery(strQuery);
            return rs;
        } catch (Exception e)
        {
            return null;
        }
    }
   public int operatedata(String strquery)
    {
       try
       {
                int k=st.executeUpdate(strquery);
                return k;

       }
       catch(Exception e)
       {
           return 0;
       }
   }
  
}
