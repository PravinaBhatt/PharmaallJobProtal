/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author DVP
 */
@WebServlet(name="change_pwd", urlPatterns={"/change_pwd"})
public class change_pwd_admin extends HttpServlet {
   
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session=request.getSession();

        String old_p=request.getParameter("oldpwd");
         String new_p=request.getParameter("newpwd");
          String re_p=request.getParameter("repwd");

        try {
          ConnectionClass cn=new ConnectionClass();
          String g="select Password from admin_profile where admin_id='"+session.getAttribute("admin_id")+"'";
          ResultSet rs=cn.getData(g);
          String pd="";
          while(rs.next())
          { pd=rs.getString("Password"); }

          if(!old_p.equals(pd))
          {
              out.println("<script type='text/javascript'>alert('Forgot your old pwd?'); window.location.href='WelComeAdmin.jsp';</script>");

          }
            else
              {


                String l="update admin_profile set Password='"+new_p+"'where admin_id='"+session.getAttribute("admin_id")+"'";
                int j=cn.operatedata(l);
                if(j==1)
                {
                        response.sendRedirect("WelComeAdmin.jsp?info="+"Password changed successfully!");
                }
                    else
                  {
                        response.sendRedirect("WelComeAdmin.jsp?info="+"Error updating your password!");
                    }
            }


          
        } 
        catch(Exception e)
        {
            out.println(e);
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
