/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.Time;
import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author DVP
 */
public class job_post extends HttpServlet {
   
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String jobtitle=request.getParameter("job_title");
        String job_category=request.getParameter("job_category");
        String job_desp=request.getParameter("job_desp");
        String company_name=request.getParameter("company_name");
         String country=request.getParameter("region");
          String state=request.getParameter("country");
          String city=request.getParameter("city_state");
          String job_experience=request.getParameter("job_experience");

          java.util.Date utilDate = new java.util.Date();

            java.sql.Date date = new java.sql.Date(utilDate.getTime());
            Time time=new Time(utilDate.getTime());
          HttpSession session=request.getSession();
         
        try {
                ConnectionClass cn=new ConnectionClass();
                int id=0;
                String q2="select Id from tbl_jobs";
                ResultSet rs=cn.getData(q2);
                while(rs.next()){ id=rs.getInt("Id"); }

                String q1="insert into tbl_jobs values ('"+(id+1)+"','"+(session.getAttribute("employer_id"))+"','"+jobtitle+"','"+job_category+"','"+job_desp+"','"+company_name+"','"+country+"','"+state+"','"+city+"','"+job_experience+"','"+date+"','"+time+"')";
                    int k=cn.operatedata(q1);
                    if(k==1)
                    {
                        out.println("<center><h2>Job posted successfully!</h2></center>");
                        response.setHeader("Refresh","1; URL=http://localhost:8080/Pharmaall/employer_jobpost.jsp");

                        
                    }
                     else
                    {
                            out.println("<script type='text/javascript'> alert('Error posting job!'); window.location.href='employer_jobpost.jsp'; </script>");
                    }
        } catch(Exception e)
        {
            out.println(e);
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
