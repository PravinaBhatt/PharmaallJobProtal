/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.*;
/**
 *
 * @author DVP
 */

public class forgot_pwd extends HttpServlet
{
   
     
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String email=request.getParameter("email");
        String id=request.getParameter("id");
       // HttpSession session=request.getSession();
        

        try
        {
                    ConnectionClass cn=new ConnectionClass();
                    //for jobseeker
                   if(id.equals("jobseeker"))
                   {
                                String l="select Password from tbl_jobseeker_login where Email='"+email+"'";
                                ResultSet rs=cn.getData(l);
                                if(rs.next())
                                {


            String 
            
            d_host = "smtp.gmail.com",
            d_port = "465",
            m_to = email, // Target email address
            m_subject = "Testing",
            m_text ="Your password is: "+rs.getString("Password");

   
         Properties props = new Properties();
        props.put("mail.smtp.user", "pooja.mistry.it.92@gmail.com");
        props.put("mail.smtp.host", d_host);
        props.put("mail.smtp.port", d_port);
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.auth", "true");
        //props.put("mail.smtp.debug", "true");
        props.put("mail.smtp.socketFactory.port", d_port);
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.socketFactory.fallback", "false");
        props.setProperty("mail.smtp.ssl.trust", "smtpserver");
        props.setProperty( "mail.smtp.ssl.enable" , "true");
        try {
            Authenticator auth = new SMTPAuthenticator();
            Session session = Session.getInstance(props, auth);
            MimeMessage msg = new MimeMessage(session);
            msg.setText(m_text);
            msg.setSubject(m_subject);
            msg.setFrom(new InternetAddress("pooja.mistry.it.92@gmail.com"));
            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(m_to));
            Transport.send(msg);
                    out.println("<script type='text/javascript'>alert('Password sent to your Email id!'); window.location.href='jobseeker.jsp';</script>");
        }
        catch (Exception mex)
        {
            mex.printStackTrace();
        }

                                }
                                else
                                {
                                            out.println("<script type='text/javascript'>alert('Your User Id not found!'); window.location.href='forgot_pwd.jsp'; </script>");
                                    }
                   }
                    //for employer
                    else if(id.equals("employer"))
                   {

                        String l="select Password from tbl_employer_profile where Email='"+email+"'";
                                ResultSet rs=cn.getData(l);
                                if(rs.next())
                                {


            String

            d_host = "smtp.gmail.com",
            d_port = "465",
            m_to = email, // Target email address
            m_subject = "Testing",
            m_text ="Your password is: "+rs.getString("Password");


         Properties props = new Properties();
        props.put("mail.smtp.user", "pooja.mistry.it.92@gmail.com");
        props.put("mail.smtp.host", d_host);
        props.put("mail.smtp.port", d_port);
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.auth", "true");
        //props.put("mail.smtp.debug", "true");
        props.put("mail.smtp.socketFactory.port", d_port);
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.socketFactory.fallback", "false");
        props.setProperty("mail.smtp.ssl.trust", "smtpserver");
        props.setProperty( "mail.smtp.ssl.enable" , "true");
        try {
            Authenticator auth = new SMTPAuthenticator();
            Session session = Session.getInstance(props, auth);
            MimeMessage msg = new MimeMessage(session);
            msg.setText(m_text);
            msg.setSubject(m_subject);
            msg.setFrom(new InternetAddress("pooja.mistry.it.92@gmail.com"));
            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(m_to));
            Transport.send(msg);
                    out.println("<script type='text/javascript'>alert('Password sent to your Email id!'); window.location.href='employer.jsp';</script>");
        }
        catch (Exception mex)
        {
            mex.printStackTrace();
        }

                                }
                                else
                                {
                                            out.println("<script type='text/javascript'>alert('Your User Id not found!'); window.location.href='forgot_pwd.jsp'; </script>");
                                    }

                    }



        }
        catch(Exception e)
        {
            out.println(e);
        }
    }
    private class SMTPAuthenticator extends javax.mail.Authenticator
    {
        public PasswordAuthentication getPasswordAuthentication()
        {
            return new PasswordAuthentication("pooja.mistry.it.92@gmail.com","ERp00jamistry(");
        }
    }
    
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

