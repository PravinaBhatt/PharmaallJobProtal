/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import Captcha.CaptchasDotNet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.Time;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author DVP
 */
public class employer_profile_registration extends HttpServlet {
   
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String name=request.getParameter("name");
        String Lname=request.getParameter("lname");
         String email=request.getParameter("email");
          String cemail=request.getParameter("cemail");
          String pwd=request.getParameter("pwd");
          String cpwd=request.getParameter("c_pwd");
           String company_name=request.getParameter("company_name");
           String phone=request.getParameter("Phone");
           String Fax=request.getParameter("Fax");
            String street_address=request.getParameter("street_address");
            String country=request.getParameter("region");
            String state=request.getParameter("country");
            String city=request.getParameter("city_state");
             String zipcode=request.getParameter("zipcode");
             String companytype=request.getParameter("companytype");
              String company_logo=request.getParameter("company_logo");
              String companyurl=request.getParameter("companyurl");
              String companydescp=request.getParameter("companydescp");
               String show_info_mailbox=request.getParameter("show_info_mailbox");
               String show_info_viewvacancies=request.getParameter("show_info_viewvacancies");

               java.util.Date utilDate = new java.util.Date();

            java.sql.Date date = new java.sql.Date(utilDate.getTime());
            Time time=new Time(utilDate.getTime());

            CaptchasDotNet Captcha = new Captcha.CaptchasDotNet
        (
  request.getSession(true),     // Ensure session
  "demo",                       // client
  "secret"                      // secret
  );
           String password = request.getParameter("captcha");

// Check captcha
switch (Captcha.check(password)) {
  case 's':
   // body = "Session seems to be timed out or broken. ";
   // body += "Please try again or report error to administrator.";
     out.println("<script type='text/javascript'> alert('Session seems to be timed out or broken, Please try again or report error to administrator.'); window.location.href='employer.jsp'; </script>");
    break;
  case 'm':
    //body = "Every CAPTCHA can only be used once. ";
   // body += "The current CAPTCHA has already been used. ";
   // body += "Please use back button and reload";
     out.println("<script type='text/javascript'> alert('The current CAPTCHA has already been used.'); window.location.href='employer.jsp'; </script>");
    break;
  case 'w':
   // body = "You entered the wrong password. ";
   // body += "Please use back button and try again. ";
     out.println("<script type='text/javascript'> alert('You entered the wrong captcha..!'); window.location.href='employer.jsp'; </script>");
    break;

}



        try {
                   ConnectionClass cn=new ConnectionClass();
                   int id=0;
                   String l="select Id from tbl_employer_profile";
                   ResultSet rs=cn.getData(l);
                     while(rs.next()) {id=rs.getInt("Id"); }

                   String q1="insert into tbl_employer_profile values ('"+(id+1)+"','"+name+"','"+Lname+"','"+email+"','"+pwd+"','"+company_name+"','"+phone+"','"+Fax+"','"+street_address+"','"+country+"','"+state+"','"+city+"','"+zipcode+"','"+companytype+"','"+company_logo+"','"+companyurl+"','"+companydescp+"','"+show_info_mailbox+"','"+show_info_viewvacancies+"','"+date+"','"+time+"')";
                    int k=cn.operatedata(q1);
                    if(k==1)
                    {

                            HttpSession session=request.getSession();
                            session.setAttribute("name",name);
                            session.setAttribute("lname",Lname);
                            session.setAttribute("email",email);
                            session.setAttribute("company_name",company_name);

                            String q2="select Id from tbl_employer_profile where Email='"+email+"'";
                            ResultSet rs1=cn.getData(q2);
                            while (rs1.next()){session.setAttribute("employer_id",rs1.getInt("Id")); }
                       out.println("<center><h2>Registered successfully!...redirecting..</h2></center>");
                            response.setHeader("Refresh","1; URL=http://localhost:8080/Pharmaall/employer_home.jsp");

                    }
                    else
                        {
                        out.println("<script type='text/javascript'> alert('Errror registering employer!'); window.location.href='employer.jsp'; </script>");
                    }
         //  out.println(name+"-"+Lname+"-"+email+"-"+pwd+"-"+cpwd+"-"+company_name+"-"+phone+"-"+Fax+"-"+street_address+"-"+country+"-"+state+"-"+city+"-"+zipcode+"-"+companytype+"-"+company_logo+"-"+companyurl+"-"+companydescp+"-"+show_info_mailbox+"-"+show_info_viewvacancies);
           

        }
        catch(Exception e)
        {
            out.println(e);
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
