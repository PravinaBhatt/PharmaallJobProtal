/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author DVP
 */
public class employer_update extends HttpServlet {
   
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session=request.getSession();

        String name=request.getParameter("name");
        String lname=request.getParameter("lname");
        String email=request.getParameter("email");
        String c_name=request.getParameter("company_name");
        String phone=request.getParameter("Phone");
        String fax=request.getParameter("Fax");
        String street_add=request.getParameter("street_address");
        String postal=request.getParameter("zipcode");
        String c_type=request.getParameter("companytype");
        String c_logo=request.getParameter("company_logo");
        String c_url=request.getParameter("companyurl");
        String c_desp=request.getParameter("companydescp");
        String n1=request.getParameter("show_info_mailbox");
        String n2=request.getParameter("show_info_viewvacancies");


        try {
            ConnectionClass cn=new ConnectionClass();
            String query1="update tbl_employer_profile set Name='"+name+"',Lastname='"+lname+"',Email='"+email+"',Company_name='"+c_name+"',Phoneno='"+phone+"',Fax='"+fax+"',Street_address='"+street_add+"',Postal_code='"+postal+"',Company_type='"+c_type+"',Company_logo='"+c_logo+"',Company_url='"+c_url+"',Company_description='"+c_desp+"',Notify1='"+n1+"',Notify2='"+n2+"' where Id='"+(session.getAttribute("employer_id"))+"'";
            String query2="update tbl_jobs set Company_name='"+c_name+"' where Employer_id='"+(session.getAttribute("employer_id"))+"'";
            int u=cn.operatedata(query2);
            int j=cn.operatedata(query1);
                        if(j==1 && u==1)
                        {
                            response.sendRedirect("employer_home.jsp?done=Profile updated successfully!");
                        }
                    else
                        {
                            out.println("<script type='text/javascript'> alert('Errror updating employer profile!'); window.location.href='employer_edit.jsp'; </script>");
                        }

        }


        catch(Exception e)
        {
            out.println(e);
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
