/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DVP
 */
import java.sql.*;
public class test {

    public static void main(String args[])
    {
        try
        {
       // java.util.Date currentDate = new java.util.Date();
//        java.util.Date utilDate = new java.util.Date();
//
//
//java.sql.Date date = new java.sql.Date(utilDate.getTime());
//Time t=new Time(utilDate.getTime());

                            ConnectionClass cn=new ConnectionClass();
                            String l="select * from tbl_jobseeker_login";
                            ResultSet rs=cn.getData(l);
                                            boolean b = rs.last();
                                         int numberOfRecords = 0;
                                        if(b){
                                                numberOfRecords = rs.getRow();
                                             }
      System.out.println(numberOfRecords);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
