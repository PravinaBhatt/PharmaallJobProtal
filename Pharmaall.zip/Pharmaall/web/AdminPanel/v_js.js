
    
    function noBack() {window.history.forward();}

function n_check()
{
    var firstname=document.forms["form1"]["firstname"].value;
    var lastname=document.forms["form1"]["lastname"].value;
    var email=document.forms["form1"]["email"].value;
    var cemail=document.forms["form1"]["confirm_email"].value;
    var pwd=document.forms["form1"]["pwd"].value;
    var cpwd=document.forms["form1"]["confirm_pwd"].value;
    var phone=document.forms["form1"]["phoneno"].value;
    var address=document.forms["form1"]["address"].value;
    var pincode=document.forms["form1"]["pincode"].value;

    var min=7;
    var max=15;
    var len3=10;
    var re=/[0-9]/;
    var reg = "^[-]?[0-9]+[\.]?[0-9]+$";
    if(firstname=="" || firstname==null || lastname=="" || lastname==null || address=="" || address==null || pwd=="" || pwd==null || cpwd=="" || cpwd==null || phone=="" || phone==null || pincode=="" || pincode==null)
        {
            alert("Please enter the data properly!");
            return false;
        }
       else if(checkEmail(email)==false)
       {
            return false;
       }
//       else if(cemail!=email)
//           {
//               alert("Retyped email doesnt match!");
//               return false;
//           }
         else if(cpwd!=pwd)
            {
                alert("Re_typed password doesnt match!");
                return false;
            }
             else if((pwd.length<min) || (pwd.length>max))
                        {
                            alert("Password length must be in between 7 to 15 characters long!");
                            return false;
                        }
                        else if(!(re.test(pwd)))
                            {
                                alert("Password must contain one numeral value [0-9]!");
                            return false;
                            }
               else if(isNaN(phone)||phone.indexOf(" ")!=-1)
                 {
                     alert("Phone no must contain numeric values!");
                     return false;
                 }
                 else if((phone.length < len3) || (phone.length > len3))
                 {
                    alert(" Your Mobile Number must be 1 to 10 Integers");
                    return false;
                 }
                 else if(isNaN(pincode)||pincode.indexOf(" ")!=-1)
                 {
                     alert("Pincode must contain numeric values!");
                     return false;
                 }

else
    {
        return true;
    }


}

function checke()
{
    var ml=document.getElementById("email");
    if(echeck(ml.value)==false)
        {
           
            return false;
        }
        else
            {
                return true;
            }
}


function echeck(str)
{

		var at="@";
		var dot=".";
		var lat=str.indexOf(at);
		var lstr=str.length;
		var ldot=str.indexOf(dot);
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID");
		   return false;
		}

		else if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID");
		   return false;
		}

		else if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID");
		    return false;
		}

		 else if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID");
		    return false;
		 }

		 else if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID");
		    return false;
		 }

		 else if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID");
		    return false;
		 }

		 else if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID");
		    return false;
		 }
                    else
                        {
                             return true;
                        }

	}
//        function l_check()
//        {
//            var email=document.getElementById("email");
//            var pwd=document.getElementById("pwd");
//
//            if((email.value=="" && pwd.value==""))
//                {
//                    alert('Please enter Email and password!');
//                    return false;
//                }
//                else if(email.value=="")
//                    {
//                        alert('Please enter the Email properly!');
//                        return false;
//                    }
//                    else if(pwd.value=="")
//                        {
//                            alert('Please enter the Password properly!');
//                            return false;
//                        }
function p_check()
{
    var fname=document.forms["form1"]["firstname"].value;
    var lname=document.forms["form1"]["lastname"].value;
    var dob=document.forms["form1"]["dob"].value;
    
     var institute=document.forms["form1"]["institutename"].value;

     var total_ex=document.forms["form1"]["ex_months"].value;
    var functional_area=document.forms["form1"]["functional_area"].value;

    //job details fr experienced people
    var jobtitle=document.forms["form1"]["jobtitle"].value;
    var companyname=document.forms["form1"]["companyname"].value;
    var industry=document.forms["form1"]["industry"].value;
    var duration=document.forms["form1"]["duration"].value;
    
    //skill details for experienced people
    var ks1=document.forms["form1"]["keyskill_word1"].value;
    var ks1_y=document.forms["form1"]["skill_years1"].value;
    var ks2=document.forms["form1"]["keyskill_word2"].value;
    var ks2_y=document.forms["form1"]["skill_years2"].value;
    var ks3=document.forms["form1"]["keyskill_word3"].value;
    var ks3_y=document.forms["form1"]["skill_years3"].value;
    var ks4=document.forms["form1"]["keyskill_word4"].value;
    var ks4_y=document.forms["form1"]["skill_years4"].value;
    var ks5=document.forms["form1"]["keyskill_word5"].value;
    var ks5_y=document.forms["form1"]["skill_years5"].value;


    var qualification=document.forms["form1"]["qualification_level"].value;
     var specialization=document.forms["form1"]["specialization"].value;

     var resume=document.forms["form1"]["resume"].value;
     var flag=0;
     
if(document.getElementById("fresher").checked)
    {
    if(fname=="" || fname==null || lname=="" || lname==null || dob=="" || dob==null ||  institute=="" || institute==null)
        {
            alert("Enter the data properly!");
            return false;
        }
        else if(total_ex=="SELECT MONTHS")
            {
                alert("Please select your total experience properly!");
                return false;
            }
        else if(functional_area=="SELECT JOB CATEGORY")
            {
                alert("Please select your functional area properly!");
                return false;
            }
            
            else if(qualification=="SELECT YOUR LEVEL")
            {
                alert("Please select your qualification level properly!");
                return false;
            }
             else if(specialization=="SELECT YOUR SPECIALIZATION")
            {
                alert("Please select your specialization  properly!");
                return false;
            }

           
            else if(resume=="")
                {
                    alert('Please browse a file to upload your resume!');
                    return false;


                }
               else if (resume.indexOf('.') != -1)
                {
                        var validExtensions = new Array();
                        validExtensions[0] = 'doc';
                        validExtensions[1] = 'docx';
                        validExtensions[2] = 'pdf';


                        var ext = resume.substring(resume.lastIndexOf('.') + 1).toLowerCase();
                        for (var i = 0; i < validExtensions.length; i++) {
                            if (ext == validExtensions[i]) {
                                flag = 1;
                                break;
                            }
                        }

                        if (flag == 0) {
                            alert('You can only Upload .doc, .docx, .pdf extensioned file!');
                            return false;
                        }
                    }
    }

    else if(document.getElementById("experienced"))
  {
            if(fname=="" || fname==null || lname=="" || lname==null || dob=="" || dob==null ||  institute=="" || institute==null)
        {
            alert("Enter the data properly!");
            return false;
        }
        else if(total_ex=="SELECT MONTHS")
            {
                alert("Please select your total experience properly!");
                return false;
            }
        else if(functional_area=="SELECT JOB CATEGORY")
            {
                alert("Please select your functional area properly!");
                return false;
            }
         else if(jobtitle=="" || jobtitle==null || companyname=="" || companyname==null || industry=="SELECT JOB CATEGORY" || duration=="SELECT YEARS")
                            {
                                alert("Fill up your job details properly!");
                                return false;
                            }
            else if(qualification=="SELECT YOUR LEVEL")
            {
                alert("Please select your qualification level properly!");
                return false;
            }
             else if(specialization=="SELECT YOUR SPECIALIZATION")
            {
                alert("Please select your specialization  properly!");
                return false;
            }
            
            else if(resume=="")
                {
                    alert('Please browse a file to upload your resume!');
                    return false;


                }
               else if (resume.indexOf('.') != -1)
                {
                        var validExtensions = new Array();
                        validExtensions[0] = 'doc';
                        validExtensions[1] = 'docx';
                        validExtensions[2] = 'pdf';


                        var ext = resume.substring(resume.lastIndexOf('.') + 1).toLowerCase();
                        for (var i = 0; i < validExtensions.length; i++) {
                            if (ext == validExtensions[i]) {
                                flag = 1;
                                break;
                            }
                        }

                        if (flag == 0) {
                            alert('You can only Upload .doc, .docx, .pdf extensioned file!');
                            return false;
                        }
                    }

                    else{return true;}


  }






                    
        else
            {
                return true;
            }
}
function check_pwd()
{
    var old_p=document.forms["change_pwd"]["oldpwd"].value;
    var new_p=document.forms["change_pwd"]["newpwd"].value;
    var confirm_p=document.forms["change_pwd"]["repwd"].value;
    var min=7;
    var max=15;
    
    if((old_p==null) || (old_p=="") || (new_p==null) || (new_p=="") || (confirm_p==null) || (confirm_p==""))
        {
            alert('Enter the values properly!');
            return false;
        }

        else if((new_p.length<min) || (new_p.length>max))
                        {
                            alert("Password length must be in between 7 to 15 characters long!");
                            return false;
                        }
                        else if(!(re.test(new_p)))
                            {
                                alert("Password must contain one numeral value [0-9]!");
                            return false;
                            }
                            else if(new_p!= confirm_p)
                                {
                                    alert('Confirm pwd doesnt match!');
                                    return false
                                }
        else
            {
                return true;
            }
}
function check_emp()
{
    var firstname=document.forms["employer_reg"]["fname"].value;
    var lastname=document.forms["employer_reg"]["lname"].value;
    var email=document.forms["employer_reg"]["email"].value;
    var cemail=document.forms["employer_reg"]["cemail"].value;
    var pwd=document.forms["employer_reg"]["pwd"].value;
    var cpwd=document.forms["employer_reg"]["c_pwd"].value;
    var company_name=document.forms["employer_reg"]["company_name"].value;
    var phone=document.forms["employer_reg"]["Phone"].value;
    var fax=document.forms["employer_reg"]["Fax"].value;
    var street_add=document.forms["employer_reg"]["street_address"].value;
    var region=document.forms["employer_reg"]["region"].value;
    var country=document.forms["employer_reg"]["country"].value;
    var city_state=document.forms["employer_reg"]["city_state"].value;
    var postal=document.forms["employer_reg"]["zipcode"].value;
    var company_type=document.forms["employer_reg"]["companytype"].value;
    var logo=document.forms["employer_reg"]["company_logo"].value;
    var url=document.forms["employer_reg"]["companyurl"].value;
    var desp=document.forms["employer_reg"]["companydescp"].value;

var min=7;
    var max=15;
    var len3=10;
    var re=/[0-9]/;
    var reg = "^[-]?[0-9]+[\.]?[0-9]+$";
    var flag=0;

    if((firstname==null) || (firstname=="") || (lastname==null) || (lastname=="") || (email==null) || (email=="") || (pwd==null) || (pwd=="") || (cpwd==null) || (cpwd=="") || (company_name==null) || (company_name=="") || (phone==null) || (phone=="") || (fax==null) || (fax=="") || (street_add==null) || (street_add=="") || (postal==null) || (postal=="") || (logo==null) || (logo=="") || (url==null) || (url=="") || (desp==null) || (desp==""))
        {
            alert('Enter the values properly!');
            return false;
        }
        else if((region=="SELECT REGION") || (country=="SELECT COUNTRY") || (city_state=="SELECT NEAREST STATE") || (company_type=="Company type"))
            {
                alert('Enter the values properly!');
            return false;
            }
            else if(cemail!=email)
        {
            alert('retyped email doesnt match!');
            return false;
        }

        else if((pwd.length<min) || (pwd.length>max))
                        {
                            alert("Password length must be in between 7 to 15 characters long!");
                            return false;
                        }
                        else if(!(re.test(pwd)))
                            {
                                alert("Password must contain one numeral value [0-9]!");
                            return false;
                            }

        else if(cpwd!=pwd)
        {
            alert('retyped password doesnt match!');
            return false;
        }
        else if(isNaN(phone)||phone.indexOf(" ")!=-1)
                 {
                     alert("Phone no must contain numeric values!");
                     return false;
                 }
                 else if(isNaN(fax)||fax.indexOf(" ")!=-1)
                 {
                     alert("Fax no must contain numeric values!");
                     return false;
                 }
                 else if(isNaN(postal)||postal.indexOf(" ")!=-1)
                 {
                     alert("Postal code must contain numeric values!");
                     return false;
                 }
                                  if(logo=="")
                {
                    alert('Please browse a file to upload company logo!');
                    return false;


                }
                else if (logo.indexOf('.') != -1)
                {
                        var validExtensions = new Array();
                        validExtensions[0] = 'jpg';
                        


                        var ext = logo.substring(logo.lastIndexOf('.') + 1).toLowerCase();
                        for (var i = 0; i < validExtensions.length; i++) {
                            if (ext == validExtensions[i]) {
                                flag = 1;
                                break;
                            }
                        }

                        if (flag == 0) {
                            alert('You can only Upload jpg images in logo !');
                            return false;
                        }
                    }
                     




                 else
            {
                return true;
            }

    


}
function check_fd()
{
    var email=document.forms["feedback"]["email"].value;
    var fd=document.forms["feedback"]["feedback"].value;
    
    if(email==null || email=="" || fd==null || fd=="")
     {
            alert('Enter the values properly!');
                            return false;
      }
      else if(echeck(email)==false)
          {
              return false;
          }

      else
          {
              return true;
          }
}
function check_cat()
{
    var cat=document.forms["findjob"]["category"].value;

    if(cat=="SELECT JOB CATEGORY")
        {
            alert('Please select the Job category properly!');
                            return false;
        }
        else
            {
                return true;
            }

}
function check_admin_profile()
{
    var name=document.forms["adminprofile"]["name"].value;
    var email=document.forms["adminprofile"]["email"].value;
    var dob=document.forms["adminprofile"]["dob"].value;
    var gender=document.forms["adminprofile"]["gender"].value;
    var desp=document.forms["adminprofile"]["desp"].value;

    if(name==null || name=="" || email==null || email==""  || desp==null || desp=="" )
        {
            alert('Please enter the values properly!');
                            return false;
        }
        else if(echeck(email)==false)
          {
              return false;
          }
          

        else
            {
                return true;
            }
}