/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import java.sql.*;

/**
 *
 * @author User
 */
public class ConnectionClass
{
    Connection con = null;
    Statement stmt = null;
    ResultSet rs = null;
    

    public Connection getConnection()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection("jdbc:mysql://localhost/pharmall","root","root");
            return con;
        }
        catch(Exception e)
        {
            return null;
        }
    }

    public ResultSet getData(String sqlQuery)
    {
        try
        {
            con = getConnection();
            stmt = con.createStatement();
            rs = stmt.executeQuery(sqlQuery);
            
            return rs;
        }
        catch(Exception e)
                {
         return null;
        }
    }

    public void deleteData(String strQuery)
    {
        try
        {
            con = getConnection();
            stmt = con.createStatement();
            stmt.execute(strQuery);
        }
        catch(Exception e)
        {
        }
    }

}
