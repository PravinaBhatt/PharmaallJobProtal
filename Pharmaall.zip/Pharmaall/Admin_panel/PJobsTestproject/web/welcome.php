<?php
include("welcome.php");

?>


<div class="grid_9 cnt" id="left">
    <h1>Dashboard</h1>
    <div id="lipsum">
      <p> Lorem ipsum dolor sit amet, <a href="#">consectetur adipiscing elit</a>. Nam sapien  dolor, ultrices a rutrum quis, convallis nec nisi. Morbi lorem est,  pellentesque ac suscipit ut, fringilla sit amet elit. Cras blandit  turpis vitae augue laoreet gravida. Suspendisse potenti. Nullam vitae  dui quam. <strong>Cras fringilla tincidunt metus venenatis suscipit. </strong>Vestibulum  feugiat felis tincidunt felis fermentum fringilla. In a ante metus.  Nullam consequat hendrerit orci quis volutpat. Etiam a libero nunc. Sed  convallis suscipit lectus quis hendrerit. </p>
<!-- WYSIWYG Div --><!--SYSTEM MESSAGE EXAMPLES-->        
      <p class="notice">Notice or Alert Message<span>X</span></p>
      <p class="success">Success Message<span>X</span></p>
      <p class="info">Informative Message<span>X</span></p>
      <p class="error">Error Message<span>X</span></p>
<!--END SYSTEM MESSAGE EXAMPLES--> 
     
<!--TABLE EXAMPLE-->      
      <h2>Table Example</h2>
      <table width="100%" border="0" cellpadding="0" cellspacing="0" id="data">
        <tr>
          <th width="15" align="center" scope="col"><label>
            <input type="checkbox" name="checkbox" id="checkbox" />
          </label></th>
          <th width="80" scope="col"><a href="#">Register Date</a></th>
          <th width="100" scope="col"><a href="#">User Name</a></th>
          <th scope="col"><a href="#">Description</a></th>
          <th width="40" scope="col"><a href="#">Actions</a></th>
        </tr>
        <tr>
          <td width="15" align="center"><input type="checkbox" name="checkbox2" id="checkbox2" /></td>
          <td width="80"> 21.01.2009</td>
          <td>test_user</td>
          <td>I love to watch movies late at night and I love american ninja.</td>
          <td width="40" align="center"><a href="#"><img src="images/icon_edit.gif" alt="Edit" width="16" height="16" border="0" /></a>&nbsp;&nbsp;<a href="#"><img src="images/icon_delete.gif" alt="Delete" width="16" height="16" border="0" /></a></td>
        </tr>
        <tr>
          <td class="odd" width="15" align="center"><input type="checkbox" name="checkbox3" id="checkbox3" /></td>
          <td class="odd" width="80"> 21.01.2009</td>
          <td class="odd">test_user</td>
          <td class="odd">I love to watch movies late at night and I love american ninja.</td>
          <td width="40" align="center" class="odd"><a href="#"><img src="images/icon_edit.gif" alt="Edit" width="16" height="16" border="0" /></a>&nbsp;&nbsp;<a href="#"><img src="images/icon_delete.gif" alt="Delete" width="16" height="16" border="0" /></a></td>
        </tr>
        <tr>
          <td width="15" align="center"><input type="checkbox" name="checkbox4" id="checkbox4" /></td>
          <td width="80"> 21.01.2009</td>
          <td>test_user</td>
          <td>I love to watch movies late at night and I love american ninja.</td>
          <td width="40" align="center"><a href="#"><img src="images/icon_edit.gif" alt="Edit" width="16" height="16" border="0" /></a>&nbsp;&nbsp;<a href="#"><img src="images/icon_delete.gif" alt="Delete" width="16" height="16" border="0" /></a></td>
        </tr>
        <tr>
          <td class="odd" width="15" align="center"><input type="checkbox" name="checkbox5" id="checkbox5" /></td>
          <td class="odd" width="80"> 21.01.2009</td>
          <td class="odd">test_user</td>
          <td class="odd">I love to watch movies late at night and I love american ninja.</td>
          <td width="40" align="center" class="odd"><a href="#"><img src="images/icon_edit.gif" alt="Edit" width="16" height="16" border="0" /></a>&nbsp;&nbsp;<a href="#"><img src="images/icon_delete.gif" alt="Delete" width="16" height="16" border="0" /></a></td>
        </tr>
        <tr>
          <td width="15" align="center"><input type="checkbox" name="checkbox6" id="checkbox6" /></td>
          <td width="80"> 21.01.2009</td>
          <td>test_user</td>
          <td>I love to watch movies late at night and I love american ninja.</td>
          <td width="40" align="center"><a href="#"><img src="images/icon_edit.gif" width="16" height="16" alt="Edit" /></a>&nbsp;&nbsp;<a href="#"><img src="images/icon_delete.gif" width="16" height="16" alt="Delete" /></a></td>
        </tr>
        <tr>
          <td class="odd" width="15" align="center"><input type="checkbox" name="checkbox7" id="checkbox7" /></td>
          <td class="odd" width="80"> 21.01.2009</td>
          <td class="odd">test_user</td>
          <td class="odd">I love to watch movies late at night and I love american ninja.</td>
          <td width="40" align="center" class="odd"><a href="#"><img src="images/icon_edit.gif" width="16" height="16" alt="Edit" /></a>&nbsp;&nbsp;<a href="#"><img src="images/icon_delete.gif" width="16" height="16" alt="Delete" /></a></td>
        </tr>
        <tr>
          <td width="15" align="center"><input type="checkbox" name="checkbox8" id="checkbox8" /></td>
          <td width="80"> 21.01.2009</td>
          <td><span class="odd">test_user</span></td>
          <td><span class="odd">I love to watch movies late at night and I love american ninja.</span></td>
          <td width="40" align="center"><a href="#"><img src="images/icon_edit.gif" width="16" height="16" alt="Edit" /></a>&nbsp;&nbsp;<a href="#"><img src="images/icon_delete.gif" width="16" height="16" alt="Delete" /></a></td>
        </tr>
        <tr>
          <th colspan="5" class="pagination" scope="col"><a href="#">&lt;&lt;</a> | <a href="#">1</a> | <a href="#">2</a> | <a href="#">3</a> | <a href="#">4</a> | <a href="#">5</a> | <a href="#">6</a> | <a href="#">7</a> | <a href="#">&gt;&gt;</a></th>
</tr>        
      </table>
<!--END TABLE EXAMPLE-->

<!--FORM ELEMENTS EXAMPLE-->            
      <p><button class="styled" type="submit"> This is a button</button> 
      <button class="brown" type="submit"> This is a button</button></p>
      <form action="" method="post" name="form1" class="nice" id="form1">
        <h2>Add new user</h2>
        <p class="left">
          <label>Username:</label>
            <input name="textfield" type="text" class="inputText" id="textfield" />
          <label>E-mail Address: </label>
            <input name="textfield2" type="text" class="inputText" id="textfield2" />
          <label>Password:</label>
            <input name="textfield3" type="text" class="inputText" id="textfield3" />
		</p>
        <p class="right">
        <label>Description:</label>
        	<textarea cols="" rows="5" class="inputText_wide"></textarea>
            <br clear="all" />
            <button class="styled" type="submit"> Submit this form</button>
        </p>
        <div class="clear"></div>
      </form>
    </div>
<!--END FORM ELEMENTS EXAMPLE-->     
    
<!--TABBED PANEL EXAMPLE-->     
    <h2>Tabbed UI interface example</h2>
			<div id="tabs">
				<ul>
					<li><a href="#tabs-1">First</a></li>
					<li><a href="#tabs-2">Second</a></li>

					<li><a href="#tabs-3">Third</a></li>
				</ul>
				<div id="tabs-1">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>
				<div id="tabs-2">Phasellus mattis tincidunt nibh. Cras orci urna, blandit id, pretium vel, aliquet ornare, felis. Maecenas scelerisque sem non nisl. Fusce sed lorem in enim dictum bibendum.</div>
				<div id="tabs-3">Nam dui erat, auctor a, dignissim quis, sollicitudin eu, felis. Pellentesque nisi urna, interdum eget, sagittis et, consequat vestibulum, lacus. Mauris porttitor ullamcorper augue.</div>
			</div>
<!-- END TABBED PANEL EXAMPLE-->   

<!-- LIST EXAMPLES-->              
    <h2><br />
    Ordered and Unordered list example</h2>
    <ul>
      <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit</li>
      <li> sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
      <li>Pellentesque nisi urna, interdum eget, sagittis et, consequat vestibulum, lacus.</li>
      <li>Mauris porttitor ullamcorper augue.</li>
</ul>
    <ol>
      <li>Mauris porttitor ullamcorper augue.</li>
      <li>Pellentesque nisi urna, interdum eget, sagittis et, consequat vestibulum, lacus.</li>
      <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit</li>
      <li>Ut enim ad minim veniam, quis nostrud exercitation ullamco </li>
      <li>laboris nisi ut aliquip ex ea commodo consequat.</li>
    </ol>
<!-- LIST EXAMPLES-->      
  </div>
<!-- END LEFT CONTENT-->  

<!-- START RIGHT CONTENT - Widget menu -->    
  <div class="grid_3">
  <!-- TODO WIDGET -->
  	<div class="widget" id="todo">
   	  <h3 class="todo">To-do list</h3>
   	  <p class="todoitem">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sapien  dolor, ultrices a rutrum quis, convallis nec nisi.<a class="close" href="#">X</a></p>
   	  <p class="todoitem">Lorem ipsum dolor sit amet, consectetur adipiscing elit.<a class="close" href="#">X</a></p>
      <p class="todoitem">Nam sapien dolor, ultrices a rutrum quis, convallis nec nisi.<a class="close" href="#">X</a></p>
      <a href="#" class="view_all">View all todo items.</a>  	</div>
	<br />
    <!-- CALENDAR WIDGET -->
    <div class="widget">
    	<h3 class="calendar">Calendar</h3>
		<div id="datepicker" align="center"></div>
    </div>
	<br />
    <!-- COMMENTS WIDGET -->
    <div class="widget" id="comments">
      <h3 class="comments">Latest Comments</h3>
      <p><span><a href="#">by Danny - 15/05/2009 - 13:24</a></span>This is a sample comment on one of our articles in the website’s content part1...</p>
      <p><span><a href="#">by Danny - 15/05/2009 - 13:24</a></span>This is a sample comment on one of our articles in the website’s content part1...</p>
      <p><span><a href="#">by Danny - 15/05/2009 - 13:24</a></span>This is a sample comment on one of our articles in the website’s content part1...</p>            
      <a href="#" class="view_all">View full comment list.</a>    </div>  
	<br />
    <!-- PHOTOS WIDGET -->
    <div class="widget" id="photos">
      <h3 class="photos">Photos</h3>
      <p><a href="#"><img alt="image" src="images/cnt_img_1.jpg" width="50" height="50" /></a><a href="#"><img alt="image" src="images/cnt_img_2.jpg" width="50" height="50" /></a><a href="#"><img alt="image" src="images/cnt_img_3.jpg" width="50" height="50" /></a><a href="#"><img alt="image" src="images/cnt_img_4.jpg" width="50" height="50" /></a><a href="#"><img alt="image" src="images/cnt_img_5.jpg" width="50" height="50" /></a><a href="#"><img alt="image" src="images/cnt_img_6.jpg" width="50" height="50" /></a><a href="#"><img alt="image" src="images/cnt_img_7.jpg" width="50" height="50" /></a><a href="#"><img alt="image" src="images/cnt_img_8.jpg" width="50" height="50" /></a><a href="#"><img alt="image" src="images/cnt_img_9.jpg" width="50" height="50" /></a></p>
      <div class="clear"></div>
      <a href="#" class="view_all">View all photos.</a>
    </div>
    <br />
    <!-- BLANK WIDGET -->
    <div class="widget">
    	<h3>Basic Blank Widget</h3>
    	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sapien  dolor, ultrices a rutrum quis, convallis nec nisi. Morbi lorem est,  pellentesque ac suscipit ut, fringilla sit amet elit. Cras blandit  turpis vitae augue laoreet gravida. Suspendisse potenti.</p>
    	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sapien  dolor, ultrices a rutrum quis, convallis nec nisi. Morbi lorem est,  pellentesque ac suscipit ut, fringilla sit amet elit. Cras blandit  turpis vitae augue laoreet gravida. Suspendisse potenti.</p>
   		 <a href="#" class="view_all">A "more of this" link.</a>
    </div>        
  </div>
  <!-- end .grid_13 - RIGHT CONTENT - Widget menu  -->
  <div class="clear"></div>
  <!--FOOTER START-->
  <div class="grid_12 cnt" id="footer">This is a basic Footer - Copyright and other information can go here. | <a href="#">link 1</a> | <a href="#">link 2</a> | <a href="#">link 3</a> | <a href="#">link 4</a></div>
  <!--FOOTER END-->
  <div class="clear"></div>
</div>
</body>
</html>
